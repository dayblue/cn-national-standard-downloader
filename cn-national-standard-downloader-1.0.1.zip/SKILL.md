---
name: cn-national-standard-downloader
description: 此技能用于从国家标准全文公开系统（openstd.samr.gov.cn）检索并下载国家标准 PDF；当官方未提供全文时，自动检索并核验第三方可下载地址（标注来源名称与链接，优先可信免费源，跳过失效/付费站点）。当用户要求"下载国标/标准""从 openstd 下载 GB/T""获取某标准全文 PDF""标准号 GB/T xxxx 下载"或提供标准名称/编号并希望拿到 PDF 时触发。
agent_created: true
version: 1.0.1
display_name: 国家标准下载器
display_name_en: CN National Standard Downloader
visibility: public
license: MIT
---

# 国家标准下载器（openstd.samr.gov.cn）

## 概述

本技能封装"检索 → 确认 → 下载"的完整 SOP，用于从国家标准全文公开系统获取国家标准 PDF。
底层依赖 `scripts/std_downloader.py`（requests + BeautifulSoup 检索解析 + Playwright 真实浏览器下载），
并配套交互式命令行入口 `scripts/main.py`。所有下载逻辑已实测可用（见 `references/sop.md`）。

**第三方回退**：当官方未提供全文（采标/废止/未公开）时，自动调用 `find_third_party()` 实时检索并
`verify_source()` 核验第三方可下载地址，优先返回可信、免费、稳定的源并标注来源名称与链接；找不到可用
地址时明确提示用户（见步骤 5）。

## 适用场景与触发条件

- 用户给出**标准名称或标准编号**（如"叉车 货叉 尺寸""GB/T 5183-2025""固体矿产绿色勘查规范"），希望下载其 PDF。
- 触发词示例：下载国标、下载标准、国标下载、openstd 下载、标准全文、GB/T 下载、标准 PDF。
- **前置判定**：仅"现行且系统提供全文"的标准可走官方直接下载（页面有"下载标准"/"在线预览"按钮）。采标类（ISO 采标）、已废止、未公开全文者无官方全文——此时本技能会**自动检索第三方回退源**（步骤 5）；若第三方也无可用地址，则明确告知用户并引导官方购买或换一条。

## 所需工具与上下文

- **运行环境**：Python ≥3.10 venv（依赖见 `scripts/requirements.txt`：requests、beautifulsoup4、lxml、ddddocr、playwright、Pillow）。
- **浏览器**：Playwright 的 Chromium（经 `_find_chromium_exe()` 自动定位，无需手动指定 build 版本）。
- **网络**：直连即可，无需代理。
- **输入**：标准名称或编号（字符串）；可选类型/状态过滤。
- **输出目录**：可写路径（默认 `./standards`）。
- 详细端点、反爬结论与验证证据见 `references/sop.md`。

## 分步骤执行流程

### 步骤 1 · 准备环境（首次）
1. 创建 venv 并安装依赖：`pip install -r scripts/requirements.txt`。
2. 安装浏览器：`python -m playwright install chromium`（若 `launch` 报 executable 缺失，属版本锁定，见注意事项 4，模块已自动绕过）。

### 步骤 2 · 检索
- 调用 `scripts/std_downloader.py` 的 `search(keyword, std_type, std_status, page, page_size)`。
- 关键词传用户给的名称/编号；`std_status` 默认用字符串 `"PUBLISHED"`（现行）。
- 返回 `(items, total, page, total_page)`；`items` 每项含 `hcno`（32 位 hex 内部 id）、`std_code`、`name_cn`、`status`。
- 若命中 0 条，提示用户更换关键词或放宽状态过滤。

### 步骤 3 · 列出结果并请用户确认
- 将结果编号列出（标准号 / 名称 / 状态 / hcno），支持翻页（`n` 下一页、`p` 上一页）。
- 让用户选择某条；对交互式场景直接用 `scripts/main.py`（它已内置"检索→列表→选择→下载→回显路径"全流程）。

### 步骤 4 · 校验全文可用性
- 对选定 `hcno` 调用 `get_meta(hcno)`，读取 `has_fulltext` / `allow_download` / `allow_preview`。
- **有全文** → 进入步骤 6 下载。
- **无全文**（采标/废止/未公开）：不要直接放弃，进入步骤 5 检索第三方回退源。

### 步骤 5 · 官方无全文时检索第三方（回退）
- 调用 `find_third_party(std_code, name_cn)`（来自 `scripts/std_downloader.py`）。
- 该函数会：构造检索词 → 实时 Web 搜索候选 → 按可信度过滤（默认剔除付费/低可信站）→
  逐个 `verify_source` 核验（可达且非付费）→ 排序返回（高可信/免费/直接 PDF 优先）。
- **有返回**时：逐项列出「来源名称 + 链接 + 是否直接 PDF + 备注」，并提示用户第三方文件可能为非官方扫描件，请核对标准号/版本与官方一致；本技能不对第三方内容负责。
- **返回空列表**时：明确告知用户「未找到经核验的可用第三方下载地址」，并给出 `third_party_portals()` 列出的已知可信站点（如中国标准服务网、标准分享网、GitHub/Gitee 开源镜像）供其自行检索；同时说明可通过官方渠道购买正版。

### 步骤 6 · 下载（仅官方有全文时）
- 调用 `download(hcno, save_path, method="auto", headless=True)`；`save_path` 用 `default_save_path(std_code, out_dir)` 生成 `<编号>.pdf`。
- `auto` 优先用 Playwright 浏览器（主方案），失败回退 HTTP 拼图（兜底）。
- 浏览器内部逻辑：打开详情页 → 点击 `.xz_btn`（优先）或 `.ck_btn` → 捕获**弹出的新标签页**内的下载 → 保存为 `save_path`。
- 若下载失败，向用户说明（多因人机验证码拦截），建议改用 `headless=False` 手动过码或检查网络。

### 步骤 7 · 回显结果
- 打印：标准编号、名称、保存路径、文件大小。
- 文件大小 < 50 KB 时警告可能非有效标准 PDF（疑似验证拦截），请人工核对。

## 关键注意事项（务必遵守，否则流程会失败）

1. **状态参数必须传字符串**：`p.p5="PUBLISHED"`，**绝不能传整数 1**（会被静默忽略，混入废止标准）。
2. **hcno 提取用正则**：从结果行整体匹配 `showInfo\('([0-9A-Fa-f]{32})'\)`，不要假定它在某固定列。
3. **下载发生在弹出新标签页**：必须用**上下文级** `ctx.on("download")` 监听器捕获，页面级 `page.on("download")` 收不到——这是下不下来的头号原因。
4. **Chromium 版本锁定**：playwright 期望的浏览器 build 可能与本机不一致导致 `launch` 报 executable 缺失；模块已用 `_find_chromium_exe()` 自动扫描 `ms-playwright/chromium-*/chrome-win64/chrome.exe` 并以 `executable_path` 传入绕过，**不要硬改版本号**。
5. **纯 requests 被反爬**：直接请求 `/viewGb`、`/viewGbImg` 返回 0 字节；必须走 Playwright 浏览器。HTTP 拼图方式仅作兜底。
6. **c.gb688.cn 必须走 HTTP**：该站 HTTPS 证书主机名不匹配，强制 HTTP。
7. **仅现行+有全文可下载**；采标/废止/未公开者无按钮，应提前识别并告知。
8. **标准编号含空格**（如 `GB/T 5183-2025`），解析与文件名净化时勿截断；编号源优先取自详情页 `table.mk1` 的 h1。
9. **官方无全文时启用第三方回退**：调用 `find_third_party(std_code, name_cn)`，它会实时 Web 搜索并 `verify_source` 核验每个候选（可达+非付费才推荐），按可信度/免费/直接 PDF 排序。默认剔除付费/低可信站（道客巴巴、原创力文档等）。若返回空列表，须明确告知用户「未找到可用第三方地址」并给出已知可信门户，切勿编造链接或把付费站当免费推荐。

## 资源

- `scripts/std_downloader.py`：核心模块（`search` / `get_meta` / `download` / `default_save_path` / `_find_chromium_exe` / `find_third_party` / `verify_source` / `web_search` / `third_party_portals`）。
- `scripts/main.py`：交互式 CLI（`python main.py [关键词]`）。
- `scripts/requirements.txt`：依赖清单。
- `references/sop.md`：端点、反爬机制、验证证据与模块 API 详述。
- `README.md`：技能介绍、开发者/维护者信息、安装与使用说明（见该文件）。
- **开发者 / 维护者**：详见 `README.md` 的「开发者 / 维护者」一节（作者署名、联系方式、许可与所属工具链）。
