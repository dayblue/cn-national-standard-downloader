# 国家标准下载 SOP · 技术参考

本文件是 `cn-national-standard-downloader` 技能的详细技术参考，补充 `SKILL.md` 中未展开的
端点、参数、反爬机制与已验证结论。实施时以本文件为准。

## 1. 站点与目标资源

- 检索/详情站：`https://openstd.samr.gov.cn/bzgk`（下文 `BASE_OPENSTD`）
- 验证码/预览图块站：`http://c.gb688.cn/bzgk/gb`（**HTTP 明文，HTTPS 证书主机名不匹配，必须用 HTTP**）

### 检索端点
`GET {BASE_OPENSTD}/std/std_list`，关键参数：
- `r`：随机浮点数（防缓存）
- `page`、`pageSize`
- `p.p1`：类型 0=全部 / 1=强制性GB / 2=推荐性GB/T / 3=指导性GB/Z
- `p.p2`：关键词（标准名称或编号）
- `p.p5`：**状态，必须是字符串枚举** `"PUBLISHED"`(现行) / `"TOBEIMP"`(即将实施) / `"WITHDRAWN"`(废止) / `""`(全部)。**传整数 1 会被静默忽略，返回含废止的所有版本。**
- `p.p6` `p.p7` `p.p90` `p.p91`：留空

返回 HTML，结果在 `table.result_list > tbody > tr`。

### 详情端点
`GET {BASE_OPENSTD}/gb/newGbInfo?hcno=<32hex>`
- 有全文时页面含 `.ck_btn`（在线预览）与/或 `.xz_btn`（下载标准）按钮。
- 标准编号在 `table.mk1 tr td h1`，文本形如 `标准号：GB/T 5183-2025`（注意编号内含空格）。
- 中文名在 `table.tdlist`：行0为「中文标准名称：…」，行2为「标准状态：…」。

## 2. 核心反爬结论（已实测）

1. **下载按钮开新标签页（popup）**：点击 `.xz_btn`/`.ck_btn` 会在新标签页打开
   `…/showGb?type=download|online&hcno=…`，真正的文件下载发生在该 popup 内。
   → 必须用**上下文级** `ctx.on("download", …)` 监听器捕获；页面级 `page.on("download")` 收不到。
2. **纯 requests 被反爬**：直接请求 `/viewGb`、`/viewGbImg` 一律返回 0 字节（空响应）。
   → 必须用 Playwright 真实浏览器执行点击与下载。
3. **直连即可**：该站点在沙箱环境中无需代理（`HTTP_PROXY` 留空也能 200）。
4. **Chromium 版本锁定**：playwright 包期望的浏览器 build 与本地已装 build 可能不一致
   （如 playwright 1.63 期望 1243，但本机先装的是 1234），直接 `launch()` 会报
   "Executable doesn't exist … chromium_headless_shell-XXXX"。
   → 用 `_find_chromium_exe()` 扫描 `~/AppData/Local/ms-playwright/chromium-*/chrome-win64/chrome.exe`
   并以 `executable_path=` 传入，绕过版本锁定。

## 3. 验证证据（实测通过）

| 标准 | hcno | 结果 |
|------|------|------|
| GB/T 48133-2026 固体矿产绿色勘查规范 | 5A30A13719881E6854F539396E22D667 | 405569 字节有效 PDF |
| GB/T 5183-2025 叉车 货叉 尺寸 | 0D1FB70566BDDE0BFE9BBD2AD17B016B | 211092 字节有效 PDF |

均经 `%PDF-1.6` 头 + `%%EOF` 校验为完整 PDF。

## 4. 环境准备

- Python 3.13 venv；依赖见 `scripts/requirements.txt`（requests, beautifulsoup4, lxml,
  ddddocr, playwright, Pillow）。
- `playwright install chromium` 安装浏览器（如版本锁定报 executable 缺失，见结论 4）。
- ddddocr 用于验证码自动识别（`_ocr_captcha`），部分标准下载前需过人机验证。

## 5. 模块 API（`scripts/std_downloader.py`）

- `search(keyword, std_type=0, std_status="", page=1, page_size=10) -> (items, total, page, total_page)`
- `get_meta(hcno) -> StdMeta`（含 `allow_preview/allow_download/has_fulltext/std_code/name_cn/status`）
- `download(hcno, save_path, method="auto"|"browser"|"http", headless=True) -> 最终路径`
  - `auto`：优先浏览器，失败回退 HTTP 拼图；`browser`：仅浏览器；`http`：仅预览图块拼接（易被反爬拦截，仅兜底）
- `default_save_path(std_code, out_dir) -> "<code>.pdf"`（已做非法字符净化）
- `_find_chromium_exe()`：自动定位本地 Chromium 可执行文件
- `find_third_party(std_code, std_name="", verify=True) -> list[dict]`：官方无全文时检索并核验第三方可下载地址，返回已排序的可用源（每项含 source/url/free/trust/direct_pdf/verified/note）；无可用源返回空列表。
- `verify_source(url) -> dict`：核验候选地址是否可达、是否直接文件、是否疑似付费（返回 reachable/is_file/likely_paid/reason 等）。
- `web_search(query, max_results=12) -> list[str]`：极简 Web 搜索（DuckDuckGo lite 优先，Bing 回退），供 `find_third_party` 取候选。
- `third_party_portals() -> list[dict]`：返回已知可信检索入口（高/中可信源），作兜底建议。

## 6. 第三方回退机制（官方无全文时）

当 `get_meta().has_fulltext == False`（采标/废止/未公开）时，不要直接放弃，改走第三方检索：

1. **候选生成**：`find_third_party(std_code, std_name)` 以内置检索词组调用 `web_search` 取候选 URL（DDG/Bing/百度三引擎合并）。
2. **可信度过滤**：按 `THIRD_PARTY_SOURCES` 的 `trust` 过滤；`low`（道客巴巴、原创力文档等付费站）默认剔除，不推荐；官方主源 `openstd.samr.gov.cn` / `std.samr.gov.cn` 亦排除（非回退目标）。
3. **检索词构造**：用 `_std_tokens()` 从标准号抽取数字片段（如 `19001-2016`）构造检索词，**不使用 "GB/T" 前缀与标准名称**——实测 "GB/T" 会被 DuckDuckGo 误判为容量单位而返回无关结果，标准名称又易引入同名教材等误报。
4. **逐项核验**：对每个候选 `verify_source()`——必须可达（HTTP 200）且非疑似付费页（命中 PAYWALL_HINTS 则跳过）才纳入；直接文件（URL 以 .pdf/.doc/.zip 结尾或响应为 application/pdf）只要 URL 已通过闸门即视为相关；HTML 页还需落地页正文含标准号关键片段（`_relevant`）。
5. **排序**：高可信 > 中可信 > 未收录；同档免费优先；同档直接 PDF 优先；同域去重保留最优。
6. **结果呈现**：返回非空时逐项给出「来源名称 + 链接 + 是否直接 PDF + 备注」，并提示第三方文件可能为非官方扫描件，需核对标准号/版本；返回空列表时必须明确告知用户「未找到经核验的可用第三方下载地址」，并给出 `third_party_portals()` 中的已知可信站点供自行检索，绝不编造链接或把付费站当免费推荐。

> 注意：第三方来源稳定性不在本技能控制范围内；`web_search` 在受限网络下可能返回空，此时 `find_third_party` 亦返回空，属预期降级，按第 5 条处理即可。
