# -*- coding: utf-8 -*-
"""
国家标准下载器 —— 交互式命令行入口

用法：
    python main.py                  # 交互式：逐个提示输入
    python main.py 叉车             # 直接以“叉车”为关键词检索
    python main.py GB/T 48133       # 直接以标准编号检索

流程：
    1. 输入标准名称或标准编号
    2. 选择标准类型 / 状态（可回车用默认）
    3. 检索并列出结果（支持翻页 n/p）
    4. 选择某条标准
    5. 校验该标准是否有全文（可预览/可下载）
    6. 下载并报告保存路径
"""

from __future__ import annotations

import os
import sys
import logging

# 让脚本可直接被 `python main.py` 运行
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import std_downloader as sd

logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(message)s")
log = logging.getLogger("main")


# --------------------------------------------------------------------------- #
# 交互辅助
# --------------------------------------------------------------------------- #
def _ask(prompt: str, default: str = "") -> str:
    try:
        val = input(f"{prompt}").strip()
    except EOFError:
        val = ""
    return val or default


def _choose(prompt: str, options: list[str], default_idx: int = 0) -> int:
    """在多个选项中选择一个，返回索引。"""
    for i, opt in enumerate(options):
        mark = ">" if i == default_idx else " "
        print(f"  {mark} {i}. {opt}")
    while True:
        raw = _ask(prompt, str(default_idx + 1))
        try:
            idx = int(raw) - 1
        except ValueError:
            print("  请输入数字。")
            continue
        if 0 <= idx < len(options):
            return idx
        print("  超出范围。")


TYPE_OPTS = [
    ("全部", sd.STD_TYPE_ALL),
    ("强制性国家标准 (GB)", sd.STD_TYPE_GB),
    ("推荐性国家标准 (GB/T)", sd.STD_TYPE_GBT),
    ("国家标准化指导性技术文件 (GB/Z)", sd.STD_TYPE_GBZ),
]
STATUS_OPTS = [
    ("现行（可下载）", sd.STD_STATUS_PUBLISHED),
    ("即将实施", sd.STD_STATUS_TOBEIMP),
    ("废止", sd.STD_STATUS_WITHDRAWN),
    ("全部", sd.STD_STATUS_ALL),
]


def _print_results(items, page, total_page, total_item):
    print("\n" + "=" * 70)
    print(f"共 {total_item} 条结果   第 {page}/{total_page} 页")
    print("=" * 70)
    for i, it in enumerate(items):
        ref = "采标" if it.is_ref else "   -"
        print(f"  [{i+1}] {it.std_code}")
        print(f"       名称：{it.name_cn}")
        print(f"       状态：{it.status}  发布：{it.pub_date}  实施：{it.impl_date}  [{ref}]")
        print(f"       hcno：{it.hcno}")
    print("-" * 70)
    print("输入序号下载；n=下一页  p=上一页；r=重新检索；q=退出")


# --------------------------------------------------------------------------- #
# 检索 + 选择 主循环
# --------------------------------------------------------------------------- #
def _do_search(keyword: str, page: int, std_type: int, std_status: str):
    return sd.search(keyword, std_type=std_type, std_status=std_status,
                     page=page, page_size=10)


def interactive(keyword_arg: str = ""):
    print("\n========== 国家标准全文公开系统 · 下载器 ==========")
    print("提示：本工具仅下载“现行且系统提供全文”的国标（强制/推荐/指导）。")
    print("      采标类（如 ISO 采标）通常无全文，无法下载。\n")

    keyword = keyword_arg
    std_type = sd.STD_TYPE_ALL
    std_status = sd.STD_STATUS_PUBLISHED  # 默认只检索现行，可后续更改

    while True:
        if not keyword:
            keyword = _ask("请输入标准名称或标准编号（回车退出）：")
            if not keyword:
                print("已退出。")
                return

        # 首次进入某关键词时，询问类型与状态
        print("\n【检索条件】")
        print(f"  关键词：{keyword}")
        ti = _choose("  标准类型（默认全部）：", [o[0] for o in TYPE_OPTS])
        std_type = TYPE_OPTS[ti][1]
        si = _choose("  标准状态（默认 现行）：", [o[0] for o in STATUS_OPTS])
        std_status = STATUS_OPTS[si][1]

        page = 1
        items, total, cur_page, total_page = _do_search(keyword, page, std_type, std_status)
        if not items:
            print("未检索到结果，请更换关键词。")
            keyword = ""
            continue

        while True:
            _print_results(items, cur_page, total_page, total)
            cmd = _ask(">> ").lower()
            if cmd == "q":
                print("已退出。")
                return
            if cmd == "r":
                keyword = ""
                break
            if cmd == "n":
                if cur_page < total_page:
                    page = cur_page + 1
                    items, total, cur_page, total_page = _do_search(keyword, page, std_type, std_status)
                else:
                    print("已是最后一页。")
                continue
            if cmd == "p":
                if cur_page > 1:
                    page = cur_page - 1
                    items, total, cur_page, total_page = _do_search(keyword, page, std_type, std_status)
                else:
                    print("已是第一页。")
                continue
            # 否则当作序号
            try:
                idx = int(cmd) - 1
            except ValueError:
                print("无效输入。")
                continue
            if not (0 <= idx < len(items)):
                print("序号超出范围。")
                continue

            selected = items[idx]
            _download_selected(selected)
            # 下载后回到结果列表，可继续选择或翻页
            cont = _ask("继续操作？(回车继续浏览 / q 退出 / r 重新检索)：").lower()
            if cont == "q":
                print("已退出。")
                return
            if cont == "r":
                keyword = ""
                break


def _download_selected(item: sd.StdResult):
    print(f"\n>>> 已选择：{item.std_code}  {item.name_cn}")
    print(">>> 正在获取该标准全文信息 ...")
    try:
        meta = sd.get_meta(item.hcno)
    except Exception as e:
        print(f"获取元数据失败：{e}")
        return

    if not meta.has_fulltext:
        print("✗ 该标准在系统中【没有全文】（无预览/下载按钮）。")
        print("  常见原因：已废止、尚未公开全文、或属于采标类标准。")
        print("  请换一条记录，或重新检索。")
        return

    print(f"✓ 该标准可下载（可预览={meta.allow_preview} 可下载={meta.allow_download}）")

    # 输出目录
    default_dir = os.path.join(os.getcwd(), "standards")
    out_dir = _ask(f"保存目录（默认 {default_dir}）：", default_dir)
    os.makedirs(out_dir, exist_ok=True)
    save_path = sd.default_save_path(meta.std_code or item.std_code, out_dir)

    # 下载方式
    method_opts = ["auto（优先浏览器，失败回退）", "browser（仅浏览器）", "http（仅预览图拼接）"]
    mi = _choose("下载方式（默认 auto）：", method_opts)
    method = ["auto", "browser", "http"][mi]

    print(f">>> 开始下载，保存为：{save_path}")
    try:
        final = sd.download(item.hcno, save_path, method=method, headless=True)
        size = os.path.getsize(final) if os.path.exists(final) else 0
        mb = size / 1024 / 1024
        print("\n" + "=" * 70)
        print("下载成功 ✅")
        print(f"  标准编号：{meta.std_code or item.std_code}")
        print(f"  标准名称：{meta.name_cn or item.name_cn}")
        print(f"  保存路径：{final}")
        print(f"  文件大小：{size} 字节 （{mb:.2f} MB）")
        print("=" * 70)
        if size < 50_000:
            print("⚠ 文件小于 50KB，可能不是有效标准 PDF，请人工核对（可能为人机验证拦截）。")
    except Exception as e:
        print(f"\n✗ 下载失败：{e}")
        print("  建议：换用 method=browser 并关闭无头模式（headless=False）手动过验证码，")
        print("        或检查网络/代理后重试。")


# --------------------------------------------------------------------------- #
def main():
    keyword = ""
    if len(sys.argv) > 1:
        keyword = " ".join(sys.argv[1:])
    interactive(keyword)


if __name__ == "__main__":
    main()
