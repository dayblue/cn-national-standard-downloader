# -*- coding: utf-8 -*-
"""
国家标准全文公开系统 (openstd.samr.gov.cn) —— 标准检索与下载核心模块

功能：
  - search()            按标准名称 / 标准编号检索，返回结构化结果列表
  - get_meta()          获取单条标准的元数据（是否可预览 / 可下载）
  - download()          下载标准文件（优先 Playwright 浏览器方式，回退 HTTP 拼图方式）

设计说明：
  - 该站点的“直接下载 / 在线预览”均依赖浏览器端 JS 与人机验证码，纯 requests 直接拉取
    /viewGb 会得到空响应（反爬）。因此最稳妥的下载方式是使用真实浏览器（Playwright）执行
    页面逻辑并捕获下载；本模块同时保留基于请求的“预览图块拼接”回退方案。
"""

from __future__ import annotations

import os
import re
import io
import time
import random
import logging
import urllib.parse
from dataclasses import dataclass, field
from typing import Optional

import requests
from bs4 import BeautifulSoup

# --------------------------------------------------------------------------- #
# 常量
# --------------------------------------------------------------------------- #
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
BASE_OPENSTD = "https://openstd.samr.gov.cn/bzgk"          # 检索 / 详情
GB688_HTTP = "http://c.gb688.cn/bzgk/gb"                   # 验证码 / 预览图块

# 标准类型（对应检索参数 p.p1）
STD_TYPE_ALL = 0
STD_TYPE_GB = 1      # 强制性国家标准
STD_TYPE_GBT = 2     # 推荐性国家标准
STD_TYPE_GBZ = 3     # 指导性技术文件

# 标准状态（对应检索参数 p.p5，站点使用字符串值）
STD_STATUS_ALL = ""
STD_STATUS_PUBLISHED = "PUBLISHED"      # 现行
STD_STATUS_TOBEIMP = "TOBEIMP"          # 即将实施
STD_STATUS_WITHDRAWN = "WITHDRAWN"      # 废止

_STATUS_CN = {"PUBLISHED": "现行", "TOBEIMP": "即将实施", "WITHDRAWN": "废止"}


def get_proxies() -> dict:
    """读取环境变量中的代理；无则留空（直连）。"""
    p = os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy") or ""
    if not p:
        return {}
    return {"http": p, "https": p}


def _new_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "zh-CN,zh;q=0.9"})
    return s


# --------------------------------------------------------------------------- #
# 数据结构
# --------------------------------------------------------------------------- #
@dataclass
class StdResult:
    hcno: str                 # 标准内部 id（32 位十六进制）
    std_code: str            # 标准编号，如 GB/T 48133-2026
    name_cn: str             # 中文名称
    is_ref: bool = False      # 是否采标
    status: str = ""          # 中文状态：现行 / 即将实施 / 废止
    pub_date: str = ""        # 发布日期
    impl_date: str = ""       # 实施日期

    @property
    def status_en(self) -> str:
        for k, v in _STATUS_CN.items():
            if v == self.status:
                return k
        return ""


@dataclass
class StdMeta:
    hcno: str
    std_code: str = ""
    name_cn: str = ""
    status: str = ""
    is_ref: bool = False
    allow_preview: bool = False   # 有 在线预览 按钮
    allow_download: bool = False  # 有 下载标准 按钮
    has_fulltext: bool = False    # 是否有全文（任一按钮即可）


# --------------------------------------------------------------------------- #
# 检索
# --------------------------------------------------------------------------- #
def search(
    keyword: str,
    std_type: int = STD_TYPE_ALL,
    std_status: str = STD_STATUS_ALL,
    page: int = 1,
    page_size: int = 10,
    proxies: Optional[dict] = None,
) -> tuple[list[StdResult], int, int, int]:
    """检索标准。

    返回 (结果列表, 总条数, 当前页, 总页数)。
    无结果时返回空列表，total_item=0。
    """
    proxies = proxies if proxies is not None else get_proxies()
    s = _new_session()
    params = {
        "r": random.random(),
        "page": page,
        "pageSize": page_size,
        "p.p1": std_type,
        "p.p2": keyword,
        "p.p5": std_status,
        "p.p6": "",
        "p.p7": "",
        "p.p90": "",
        "p.p91": "",
    }
    resp = s.get(f"{BASE_OPENSTD}/std/std_list", params=params,
                 proxies=proxies, timeout=30)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")

    items: list[StdResult] = []
    for row in soup.select("table.result_list > tbody > tr"):
        tds = row.find_all("td")
        if len(tds) < 9:
            continue
        m = re.search(r"showInfo\('([0-9A-Fa-f]{32})'\)", str(row))
        if not m:
            continue
        hcno = m.group(1)
        code = tds[1].get_text(strip=True)
        is_ref = bool(tds[3].select_one("span"))
        name = tds[4].get_text(strip=True)
        status = tds[6].get_text(strip=True)
        pub = (tds[7].get_text(strip=True) or "")[:10]
        impl = (tds[8].get_text(strip=True) or "")[:10]
        items.append(StdResult(hcno=hcno, std_code=code, name_cn=name,
                              is_ref=is_ref, status=status,
                              pub_date=pub, impl_date=impl))

    # 分页信息：文本形如 “共 19 条标准 1 / 2”
    total_item = 0
    total_page = 1
    span = soup.select_one("div.hidden-xs > table > tr > td:nth-of-type(1) > span")
    if span:
        txt = span.get_text(" ", strip=True)
        mt = re.search(r"共\s*(\d+)\s*条", txt)
        if mt:
            total_item = int(mt.group(1))
        mp = re.search(r"(\d+)\s*/\s*(\d+)", txt)
        if mp:
            page = int(mp.group(1))
            total_page = int(mp.group(2))

    return items, total_item, page, total_page


# --------------------------------------------------------------------------- #
# 元数据
# --------------------------------------------------------------------------- #
def get_meta(hcno: str, proxies: Optional[dict] = None) -> StdMeta:
    """获取标准元数据，重点是是否可预览 / 可下载。"""
    proxies = proxies if proxies is not None else get_proxies()
    s = _new_session()
    resp = s.get(f"{BASE_OPENSTD}/gb/newGbInfo", params={"hcno": hcno},
                 proxies=proxies, timeout=30)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")

    meta = StdMeta(hcno=hcno)
    meta.allow_preview = bool(soup.select_one(".ck_btn"))
    meta.allow_download = bool(soup.select_one(".xz_btn"))
    meta.has_fulltext = meta.allow_preview or meta.allow_download

    # 标准编号：table.mk1 的 h1 形如 “标准号：GB/T 5183-2025”
    h1 = soup.select_one("table.mk1 tr td h1")
    if h1:
        m = re.search(r"(?:标准号[:：]\s*)([A-Za-z0-9/.\-]+(?:\s+[A-Za-z0-9/.\-]+)*)",
                      h1.get_text())
        meta.std_code = m.group(1) if m else h1.get_text(strip=True)

    # 详情表：中文名称 / 状态
    tdl = soup.select_one("table.tdlist")
    if tdl:
        full = tdl.get_text(" ", strip=True)
        m = re.search(r"中文标准名称[:：]\s*([^\n]+?)(?:\s*英文标准名称|$)", full)
        if m:
            meta.name_cn = m.group(1).strip()
        m = re.search(r"标准状态[:：]\s*(\S+)", full)
        if m:
            meta.status = m.group(1)

    # 兜底：详情首行若含编号则补充
    if not meta.std_code:
        h = soup.select_one("table.tdlist tr:nth-of-type(1) h1, table.tdlist tr:nth-of-type(1) b")
        if h:
            m = re.search(r"([A-Za-z0-9/.\-]+(?:\s+[A-Za-z0-9/.\-]+)*)", h.get_text())
            if m:
                meta.std_code = m.group(1)
    return meta


# --------------------------------------------------------------------------- #
# 验证码（HTTP 拼图回退用）
# --------------------------------------------------------------------------- #
def _ocr_captcha(img_bytes: bytes) -> Optional[str]:
    try:
        import ddddocr  # type: ignore
    except Exception:
        return None
    try:
        ocr = ddddocr.DdddOcr(show_ad=False)
        return ocr.classification(img_bytes)
    except Exception:
        return None


def solve_captcha_http(session: requests.Session, proxies: dict) -> bool:
    """在 c.gb688.cn 上完成人机验证码校验。成功返回 True。"""
    for _ in range(8):
        ts = int(time.time() * 1000)
        r = session.get(f"{GB688_HTTP}/gc?_{ts}", proxies=proxies, timeout=30)
        if r.status_code != 200:
            continue
        code = _ocr_captcha(r.content)
        if not code:
            continue
        v = session.post(f"{GB688_HTTP}/verifyCode",
                         data={"verifyCode": code}, proxies=proxies, timeout=30)
        if v.text.strip() == "success":
            return True
    return False


# --------------------------------------------------------------------------- #
# 下载方式一：HTTP 预览图块拼接（回退方案）
# --------------------------------------------------------------------------- #
def download_tile_assembly(
    hcno: str,
    save_path: str,
    proxies: Optional[dict] = None,
    logger: Optional[logging.Logger] = None,
) -> bool:
    """通过在线预览页抓取图块并拼为 PDF（无文本层）。返回是否成功。"""
    import urllib.parse
    from PIL import Image

    proxies = proxies if proxies is not None else get_proxies()
    log = logger or logging.getLogger("std_downloader")
    s = _new_session()

    if not solve_captcha_http(s, proxies):
        log.warning("验证码自动识别失败，无法使用拼图方式")
        return False

    ref = f"{BASE_OPENSTD}/gb/newGbInfo?hcno={hcno}"
    r = s.get(f"{GB688_HTTP}/showGb", params={"type": "online", "hcno": hcno},
              headers={"Referer": ref}, proxies=proxies, timeout=60)
    if r.status_code != 200:
        return False
    soup = BeautifulSoup(r.text, "lxml")
    pages = soup.select("div#viewer div.page")
    if not pages:
        return False

    page_objs = []
    for page in pages:
        bg_attr = urllib.parse.unquote(page.get("bg", ""))
        style = page.get("style", "")
        mh = re.search(r"height:\s*(\d+)px", style)
        mw = re.search(r"width:\s*(\d+)px", style)
        if not (mh and mw):
            continue
        ph, pw = int(mh.group(1)), int(mw.group(1))
        blocks = []
        for blk in page.select('span[class^="pdfImg"]'):
            cls = blk.get("class", [""])[0]
            parts = cls.split("-")
            if len(parts) < 3:
                continue
            bx, by = int(parts[1]), int(parts[2])
            bm = re.search(r"background-position:\s*-(\d+)px\s+-(\d+)px", blk.get("style", ""))
            if not bm:
                continue
            blocks.append((bx, by, int(bm.group(1)), int(bm.group(2))))
        if not blocks:
            continue
        # 抓取背景大图
        img_resp = s.get(f"{GB688_HTTP}/viewGbImg",
                         params={"fileName": urllib.parse.quote(bg_attr, safe="")},
                         proxies=proxies, timeout=60)
        if img_resp.status_code != 200 or not img_resp.content:
            continue
        raw = Image.open(io.BytesIO(img_resp.content)).convert("RGBA")
        # 背景透明 -> 白底
        bg_white = Image.new("RGB", raw.size, (255, 255, 255))
        bg_white.paste(raw, mask=raw.split()[-1])
        raw_rgb = bg_white
        block_h = ph // 10
        block_w = pw // 10
        canvas = Image.new("RGB", (pw, ph), (255, 255, 255))
        for bx, by, ix, iy in blocks:
            tile = raw_rgb.crop((ix, iy, ix + block_w, iy + block_h))
            canvas.paste(tile, (bx * block_w, by * block_h))
        page_objs.append(canvas)

    if not page_objs:
        return False

    os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
    first = page_objs.pop(0)
    first.save(save_path, "PDF", resolution=100.0,
               save_all=True, append_images=page_objs)
    return True


# --------------------------------------------------------------------------- #
# 下载方式二：Playwright 真实浏览器（主方案）
# --------------------------------------------------------------------------- #
def _find_chromium_exe() -> Optional[str]:
    """在 Playwright 浏览器目录中查找已安装的 Chromium 可执行文件。

    优先返回完整版 chromium（chrome.exe）；找不到时退回 headless shell。
    这样即便 playwright 期望的浏览器版本与本地已安装版本不一致，也能复用。
    """
    import glob
    base = os.environ.get("PLAYWRIGHT_BROWSERS_PATH") or os.path.join(
        os.path.expanduser("~"), "AppData", "Local", "ms-playwright"
    )
    patterns = [
        "chromium-*/chrome-win64/chrome.exe",
        "chromium-*/chrome-win/chrome.exe",
        "chromium_headless_shell-*/chrome-headless-shell-win64/chrome-headless-shell.exe",
    ]
    for pat in patterns:
        hits = sorted(glob.glob(os.path.join(base, pat)), reverse=True)
        if hits:
            return hits[0]
    return None


def download_browser(
    hcno: str,
    save_path: str,
    proxies: Optional[dict] = None,
    headless: bool = True,
    logger: Optional[logging.Logger] = None,
    chromium_exe: Optional[str] = None,
) -> str:
    """使用 Playwright 真实浏览器完成下载。

    关键点：
      - 站点“下载标准 / 在线预览”按钮会打开**新标签页（popup）**，真正的下载发生在
        该 popup 内，因此下载事件必须用“上下文级”监听器（ctx.on("download")）捕获。
      - 部分情况下 popup 会先弹出人机验证码，需识别并提交后才能下载。
      - 若无直接下载入口但可在线预览，则把预览页打印为 PDF 作为兜底。

    返回保存路径；失败抛出 RuntimeError。
    """
    from playwright.sync_api import sync_playwright

    proxies = proxies if proxies is not None else get_proxies()
    log = logger or logging.getLogger("std_downloader")
    proxy_arg = {"server": proxies["http"]} if proxies.get("http") else None

    os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)

    launch_kwargs = dict(
        headless=headless,
        proxy=proxy_arg,
        args=[
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-gpu",
            "--disable-software-rasterizer",
        ],
    )
    exe = chromium_exe or _find_chromium_exe()
    if exe:
        log.info("使用 Chromium: %s", exe)
        launch_kwargs["executable_path"] = exe

    with sync_playwright() as p:
        browser = p.chromium.launch(**launch_kwargs)
        ctx = browser.new_context(accept_downloads=True, user_agent=USER_AGENT)

        download_path = {"value": None}
        popups: list = []

        def _on_page(pg):
            popups.append(pg)
            log.info("新标签页: %s", pg.url)

        def _on_download(download):
            try:
                download.save_as(save_path)
                download_path["value"] = save_path
                log.info("捕获下载: %s", download.suggested_filename)
            except Exception as e:  # pragma: no cover
                log.warning("save_as 失败: %s", e)

        ctx.on("page", _on_page)
        ctx.on("download", _on_download)

        page = ctx.new_page()
        info_url = f"{BASE_OPENSTD}/gb/newGbInfo?hcno={hcno}"
        page.goto(info_url, wait_until="domcontentloaded", timeout=60000)

        allow_download = bool(page.query_selector(".xz_btn"))
        allow_preview = bool(page.query_selector(".ck_btn"))
        if not (allow_download or allow_preview):
            browser.close()
            raise RuntimeError("该标准未提供全文（无预览/下载按钮），无法下载")

        if allow_download:
            page.click(".xz_btn")
        else:
            page.click(".ck_btn")

        # 主等待：下载通常经由 popup 触发，由上下文级监听器捕获
        if not download_path["value"]:
            try:
                ctx.wait_for_event("download", timeout=25000)
            except Exception:
                pass

        # 若仍未捕获，可能是 popup 的验证码拦截 -> 处理各 popup 的验证码后重试
        if not download_path["value"]:
            time.sleep(2)
            for pg in popups:
                if pg.url and ("showGb" in pg.url or "gb688" in pg.url):
                    _handle_captcha_modal(pg, log)
            try:
                ctx.wait_for_event("download", timeout=25000)
            except Exception:
                pass

        # 兜底：把可预览的 popup 打印为 PDF
        if not download_path["value"]:
            for pg in popups:
                if _try_print_preview(pg, save_path, log):
                    download_path["value"] = save_path
                    break
            if not download_path["value"]:
                if _try_print_preview(page, save_path, log):
                    download_path["value"] = save_path

        browser.close()

    if not download_path["value"]:
        raise RuntimeError("浏览器下载未成功捕获文件")
    return download_path["value"]


def _handle_captcha_modal(page, log):
    """尝试在弹出的验证码模态框/表单中识别并提交（主页面或 popup 均适用）。"""
    try:
        modal = page.query_selector("#myModal") or page.query_selector(".modal")
        if not modal:
            if not page.query_selector("input[type='text'], input:has(img)"):
                return
            modal = page
        img = modal.query_selector("img")
        if not img:
            return
        time.sleep(1.5)
        img_bytes = img.screenshot()
        code = _ocr_captcha(img_bytes)
        if not code:
            return
        inp = modal.query_selector("input")
        if inp:
            inp.fill(code)
        for sel in [".verify-btn", "button:has-text('验证')",
                    "button:has-text('确定')", "button:has-text('提交')",
                    ".btn-primary"]:
            btn = modal.query_selector(sel)
            if btn:
                btn.click()
                break
        log.info("已提交验证码: %s", code)
        time.sleep(2)
    except Exception as e:
        log.warning("处理验证码模态框失败: %s", e)


def _try_print_preview(page, save_path, log) -> bool:
    """若页面处于在线预览页（div#viewer 已渲染），直接打印为 PDF。返回是否成功。"""
    try:
        if "showGb" not in page.url and not page.query_selector("div#viewer"):
            return False
        page.wait_for_selector("div#viewer div.page", timeout=20000)
        time.sleep(2)
        page.pdf(path=save_path, format="A4", print_background=True)
        log.info("已将预览页打印为 PDF")
        return True
    except Exception as e:
        log.warning("预览打印失败: %s", e)
        return False


# --------------------------------------------------------------------------- #
# 统一入口
# --------------------------------------------------------------------------- #
def download(
    hcno: str,
    save_path: str,
    method: str = "auto",
    headless: bool = True,
    proxies: Optional[dict] = None,
    logger: Optional[logging.Logger] = None,
) -> str:
    """下载标准文件。

    method:
      "auto"      优先浏览器，失败回退 HTTP 拼图
      "browser"   仅浏览器
      "http"      仅 HTTP 拼图
    返回最终保存路径。
    """
    proxies = proxies if proxies is not None else get_proxies()
    log = logger or logging.getLogger("std_downloader")

    if method in ("auto", "browser"):
        try:
            return download_browser(hcno, save_path, proxies=proxies,
                                    headless=headless, logger=log)
        except Exception as e:
            log.warning("浏览器下载失败: %s", e)
            if method == "browser":
                raise
    if method in ("auto", "http"):
        if download_tile_assembly(hcno, save_path, proxies=proxies, logger=log):
            return save_path
    raise RuntimeError("所有下载方式均失败")


def default_save_path(std_code: str, out_dir: str = ".") -> str:
    safe = re.sub(r"[\\/:*?\"<>|]", "_", std_code)
    return os.path.join(out_dir, f"{safe}.pdf")


# --------------------------------------------------------------------------- #
# 第三方来源检索与核验（官方无全文时的回退）
# --------------------------------------------------------------------------- #
# 可信第三方标准文件来源（按可信度/免费性标注，供排序与提示）
# trust: high=官方/权威镜像, medium=知名免费分享库/开源镜像, low=付费或需注册(仅兜底、默认不推荐)
THIRD_PARTY_SOURCES = [
    {"name": "全国标准信息公共服务平台（官方）", "domain": "openstd.samr.gov.cn",
     "free": True, "trust": "high",
     "note": "官方权威、免费；但多数标准无全文（本技能主源）"},
    {"name": "中国标准服务网", "domain": "spc.org.cn",
     "free": True, "trust": "high",
     "note": "标委官方主办，部分标准可免费预览/下载"},
    {"name": "标准分享网", "domain": "bzfxw.com",
     "free": True, "trust": "medium",
     "note": "用户分享，常有直接 PDF；但完整性/清晰度参差，需核对"},
    {"name": "GitHub 开源标准镜像", "domain": "github.com",
     "free": True, "trust": "medium",
     "note": "开源仓库镜像，免费稳定；需核对版本与官方一致性"},
    {"name": "Gitee 开源标准镜像", "domain": "gitee.com",
     "free": True, "trust": "medium",
     "note": "同上，国内访问通常更稳"},
    {"name": "工标网", "domain": "csres.com",
     "free": False, "trust": "medium",
     "note": "信息全，但下载多需付费购买"},
    {"name": "道客巴巴", "domain": "doc88.com",
     "free": False, "trust": "low",
     "note": "常需积分/付费，仅兜底"},
    {"name": "原创力文档", "domain": "book118.com",
     "free": False, "trust": "low",
     "note": "常需付费，仅兜底"},
    # —— 以下为实测可下载、已核验的权威/可信镜像（官方无全文时的优质回退） ——
    {"name": "国家药品监督管理局医疗器械技术审评中心（CMDE）", "domain": "cmde.org.cn",
     "free": True, "trust": "high",
     "note": "国家药监局直属官方机构，免费提供部分 GB/T 标准 PDF 全文；权威可信，下载后请核对标准号/版本"},
    {"name": "cncsit.cn（已实测可下载 GB/T 标准 PDF，站点身份待核实）", "domain": "cncsit.cn",
     "free": True, "trust": "unknown",
     "note": "实测可取到 GB/T 19001-2016 有效 PDF，但站点运营主体未核实，下载后务必人工核对标准号/版本/清晰度"},
    # —— 以下为实测可直链下载有效国标 PDF 的第三方站点（官方无全文时的优质回退） ——
    {"name": "cpgov.com.cn（实测直链 GB/T 45081-2024 有效 PDF）", "domain": "cpgov.com.cn",
     "free": True, "trust": "medium",
     "note": "实测可直链取到 GB/T 45081-2024（/ISO/IEC 42001:2023）完整 47 页有效 PDF；站点性质未完全核实，下载后请核对标准号/版本"},
]

# 付费/登录页特征词（命中即视为疑似付费，不推荐）
PAYWALL_HINTS = ["付费", "购买", "充值", "积分", "会员", "需登录", "立即购买",
                 "开通会员", "coin", "Coin", "VIP", "vip", "付费下载", "购买此标准"]


def _match_source(host: str) -> Optional[dict]:
    """按域名匹配第三方来源元信息。"""
    host = (host or "").lower()
    for s in THIRD_PARTY_SOURCES:
        if s["domain"] in host:
            return s
    return None


def web_search(query: str, max_results: int = 12, proxies=None, timeout: int = 15) -> list:
    """极简 Web 搜索：优先 DuckDuckGo lite，回退 Bing。返回结果 URL 列表（已去 duckduckgo 重定向）。"""
    proxies = proxies if proxies is not None else get_proxies()
    urls: list = []
    # 1) DuckDuckGo lite
    try:
        q = urllib.parse.quote_plus(query)
        r = requests.get(f"https://lite.duckduck.com/lite/?q={q}",
                         headers={"User-Agent": USER_AGENT},
                         proxies=proxies, timeout=timeout)
        if r.status_code == 200:
            soup = BeautifulSoup(r.text, "lxml")
            for a in soup.select("a.result-link") or soup.select("a[href^='http']"):
                href = a.get("href", "")
                if "uddg=" in href:
                    u = urllib.parse.parse_qs(urllib.parse.urlparse(href).query).get("uddg")
                    if u:
                        urls.append(u[0])
                elif href.startswith("http") and "duckduckgo.com" not in href:
                    urls.append(href)
    except Exception:
        pass
    # 2) Bing 回退（始终补充，提高召回）
    try:
        q = urllib.parse.quote_plus(query)
        r = requests.get(f"https://www.bing.com/search?q={q}",
                         headers={"User-Agent": USER_AGENT},
                         proxies=proxies, timeout=timeout)
        if r.status_code == 200:
            soup = BeautifulSoup(r.text, "lxml")
            for a in soup.select("li.b_algo h2 a"):
                href = a.get("href", "")
                if href.startswith("http"):
                    urls.append(href)
    except Exception:
        pass
    # 3) 百度（中文召回更优，尽力而为）
    try:
        q = urllib.parse.quote_plus(query)
        r = requests.get("https://www.baidu.com/s", params={"wd": q},
                         headers={"User-Agent": USER_AGENT,
                                  "Accept-Language": "zh-CN,zh;q=0.9"},
                         proxies=proxies, timeout=timeout)
        if r.status_code == 200:
            soup = BeautifulSoup(r.text, "lxml")
            for a in soup.select("h3.t a, div.result h3 a, .c-container h3 a"):
                href = a.get("href", "")
                if href.startswith("http"):
                    urls.append(href)
    except Exception:
        pass
    seen, out = set(), []
    for u in urls:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out[:max_results]


def verify_source(url: str, proxies=None, timeout: int = 20) -> dict:
    """核验候选地址：是否可达、是否直接文件、是否疑似付费。

    返回 {url, reachable, is_file, content_type, size, likely_paid, reason}。
    """
    proxies = proxies if proxies is not None else get_proxies()
    res = {"url": url, "reachable": False, "is_file": False,
           "content_type": "", "size": 0, "likely_paid": False,
           "snippet": "", "reason": ""}
    try:
        r = requests.get(url, headers={"User-Agent": USER_AGENT},
                         proxies=proxies, timeout=timeout,
                         allow_redirects=True, stream=True)
        res["reachable"] = (r.status_code == 200)
        ctype = r.headers.get("Content-Type", "")
        res["content_type"] = ctype
        cd = r.headers.get("Content-Disposition", "")
        clen = r.headers.get("Content-Length")
        if clen:
            try:
                res["size"] = int(clen)
            except ValueError:
                pass
        is_pdf = ("application/pdf" in ctype
                  or url.lower().endswith(".pdf")
                  or ".pdf" in cd.lower()
                  or "filename" in cd.lower())
        chunk = b""
        for part in r.iter_content(8192):
            chunk += part
            if len(chunk) >= 32768:
                break
        r.close()
        res["is_file"] = is_pdf
        text = chunk.decode("utf-8", "ignore")
        res["likely_paid"] = any(h in text for h in PAYWALL_HINTS)
        res["snippet"] = text[:2000]
        if not res["reachable"]:
            res["reason"] = "HTTP 状态非 200"
        elif res["likely_paid"]:
            res["reason"] = "疑似付费/需登录页面"
        elif is_pdf:
            res["reason"] = "可用（直接文件）"
        else:
            res["reason"] = "可用（页面，需点选下载）"
    except Exception as e:  # noqa: BLE001
        res["reason"] = f"请求异常：{e}"
    return res


def third_party_portals() -> list:
    """返回已知可信的检索入口（兜底建议用），含站点 URL。"""
    out = []
    for s in THIRD_PARTY_SOURCES:
        if s["trust"] in ("high", "medium"):
            out.append({
                "source": s["name"], "domain": s["domain"],
                "url": f"https://{s['domain']}",
                "free": s["free"], "trust": s["trust"], "note": s["note"],
            })
    return out


def _std_tokens(std_code: str) -> list:
    """从标准号抽取用于相关性匹配的关键片段，如 ['19001','19001-2016','GB/T19001-2016']。"""
    code = std_code.replace(" ", "")
    tokens = []
    m = re.search(r"(\d{3,6})", code)
    if m:
        tokens.append(m.group(1))
        tokens.append(code[m.start():])
    tokens.append(code)
    seen, out = set(), []
    for t in tokens:
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out


def _relevant(text: str, tokens: list) -> bool:
    low = (text or "").lower()
    for t in tokens:
        if t.lower() in low:
            return True
    return False


# 第三方回退定向检索的优先可信主机（site: 定向，提升相关性）
_TP_TARGET_HOSTS = ["github.com", "gitee.com", "bzfxw.com", "spc.org.cn", "csres.com"]
# 官方主源（非回退目标，命中则排除）
_TP_OFFICIAL = ("openstd.samr.gov.cn", "std.samr.gov.cn")


def find_third_party(std_code: str, std_name: str = "", proxies=None,
                     verify: bool = True, timeout: int = 15,
                     max_verify: int = 12) -> list:
    """当官方无全文时，检索并核验第三方可下载地址。

    流程：构造检索词 → Web 搜索取候选 → 按来源可信度过滤（默认剔除 low/付费站）
          → 逐个 verify_source（可达且非付费）→ 排序（高可信/免费/直接文件优先）。

    返回已排序的可用源列表；每项 {source, url, free, trust, direct_pdf, verified, note}。
    无可用源时返回空列表（调用方需明确提示用户）。
    """
    proxies = proxies if proxies is not None else get_proxies()
    tokens = _std_tokens(std_code)
    # 用数字片段（如 19001-2016）构造检索词，避免 "GB/T" 被搜索引擎误判为容量单位而返回无关结果；
    # 不使用标准名称/ site: 限定词，以免引入无关 PDF（如同名教材）造成误报
    num = tokens[1] if len(tokens) > 1 else tokens[0]
    queries = [
        f"{num} 标准 下载",
        f"{num} 国家标准 pdf 下载",
        f"{num} 标准 全文 下载",
    ]

    raw: list = []
    for q in queries:
        if not q:
            continue
        for u in web_search(q, max_results=8, proxies=proxies, timeout=timeout):
            raw.append(u)
    seen, uniq = set(), []
    for u in raw:
        if u not in seen:
            seen.add(u)
            uniq.append(u)

    results = []
    seen_domain = set()
    checked = 0
    for url in uniq:
        host = urllib.parse.urlparse(url).netloc.lower()
        if any(o in host for o in _TP_OFFICIAL):
            continue
        src = _match_source(host)
        if src and src.get("trust") == "low":
            continue  # 低可信/付费站默认不推荐
        is_direct = url.lower().endswith((".pdf", ".doc", ".docx", ".zip"))
        if not (is_direct or _relevant(url, tokens)):
            continue  # 相关性闸门：直接文件 或 URL 含标准号关键片段 才进入核验
        entry = {
            "source": src["name"] if src else host,
            "url": url,
            "free": src["free"] if src else None,
            "trust": src["trust"] if src else "unknown",
            "direct_pdf": False,
            "verified": False,
            "note": src["note"] if src else "未收录来源，请自行核对可靠性",
        }
        if verify:
            if checked >= max_verify:
                break
            checked += 1
            v = verify_source(url, proxies=proxies, timeout=timeout)
            if not (v["reachable"] and not v["likely_paid"]):
                continue
            # 直接文件：URL 已通过闸门即可；HTML 页还需落地页正文含标准号
            if not (v["is_file"] or _relevant(v.get("snippet", ""), tokens)):
                continue
            entry["verified"] = True
            entry["direct_pdf"] = v["is_file"]
            entry["size"] = v.get("size", 0)
        dom = host.replace("www.", "")
        if dom in seen_domain:
            continue
        seen_domain.add(dom)
        results.append(entry)

    order = {"high": 0, "medium": 1, "unknown": 2, "low": 3}
    results.sort(key=lambda e: (order.get(e["trust"], 2),
                                0 if e["free"] else 1,
                                0 if e.get("direct_pdf") else 1))
    return results
